library(data.table)
library(DescTools)

setwd("~/Downloads/TFM/Forecast")

data <- fread("SerieTotal2016_ext_selected.csv", sep=",", header=T)
#ek_list = unique(data$element_key)
# 1037  1045  1046  1433  9510 11878 
# 12289 13549 13793 14677 18622 24557 
# 30698 34938 35681 35682 37134 37177
# 41030 59958 62458 63125 69098 76961 
# 76962 79741 81117 85381 85385 86449

ek_list = c(30698, 34938, 35681, 35682, 37134, 37177,
            41030, 59958, 62458, 63125, 69098, 76961,
            76962, 79741, 81117, 85381, 85385, 86449)
for (ek in ek_list){
  results <- matrix(ncol = 1, nrow = 0)
  file_string = paste("ek_resultados_",toString(ek),".csv", sep="")
  conn <- file(file_string, open="r")
  lines <- readLines(conn)
  for (i in 1:length(lines)){
    results[i] <- strsplit(lines[i], ",", fixed=TRUE)
  }
  close(conn)
  
  vr_LLSR <- c()
  vr_LLCR <- c()
  vr_ArSR <- c()
  vr_ArCR <- c()
  vr_LLTSR <- c()
  vr_LLTCR <- c()
  
  for (i in seq(10,(length(results[[2]])-1))){
    vr_LLSR <- rbind(vr_LLSR, as.double(results[[2]][i]))
  }
  for (i in seq(10,(length(results[[4]])-1))){
    vr_LLCR <- rbind(vr_LLCR, as.double(results[[4]][i]))
  } 
  for (i in seq(10,(length(results[[6]])-1))){  
    vr_ArSR <- rbind(vr_ArSR, as.double(results[[6]][i]))
  }
  for (i in seq(10,(length(results[[8]])-1))){  
    vr_ArCR <- rbind(vr_ArCR, as.double(results[[8]][i]))
  }
  for (i in seq(10,(length(results[[10]])-1))){ 
    vr_LLTSR <- rbind(vr_LLTSR, as.double(results[[10]][i]))
  }
  for (i in seq(10,(length(results[[12]])-1))){ 
    vr_LLTCR <- rbind(vr_LLTCR, as.double(results[[12]][i]))
  }
  
  for (i in seq(1,(length(results[[3]])-2))){
    vr_LLSR <- rbind(vr_LLSR, as.double(results[[3]][i]))
  }
  for (i in seq(1,(length(results[[5]])-2))){
    vr_LLCR <- rbind(vr_LLCR, as.double(results[[5]][i]))
  } 
  for (i in seq(1,(length(results[[7]])-2))){  
    vr_ArSR <- rbind(vr_ArSR, as.double(results[[7]][i]))
  }
  for (i in seq(1,(length(results[[9]])-2))){  
    vr_ArCR <- rbind(vr_ArCR, as.double(results[[9]][i]))
  }
  for (i in seq(1,(length(results[[11]])-2))){ 
    vr_LLTSR <- rbind(vr_LLTSR, as.double(results[[11]][i]))
  }
  for (i in seq(1,(length(results[[13]])-2))){ 
    vr_LLTCR <- rbind(vr_LLTCR, as.double(results[[13]][i]))
  }
  
  vr_LLSR <- rbind(vr_LLSR, as.double(substr(results[[2]][9], 3, 20)))
  vr_LLCR <- rbind(vr_LLCR, as.double(substr(results[[4]][9], 3, 20)))
  vr_ArSR <- rbind(vr_ArSR, as.double(substr(results[[6]][9], 3, 20)))
  vr_ArCR <- rbind(vr_ArCR, as.double(substr(results[[8]][9], 3, 20)))
  vr_LLTSR <- rbind(vr_LLTSR, as.double(substr(results[[10]][9], 3, 20)))
  vr_LLTCR <- rbind(vr_LLTCR, as.double(substr(results[[12]][9], 3, 20)))
  
  vr_LLSR <- rbind(vr_LLSR, as.double(substr(results[[3]][length(results[[3]])-1], 1, 
                                             stop=nchar(results[[3]][20])-1)))
  vr_LLCR <- rbind(vr_LLCR, as.double(substr(results[[5]][length(results[[5]])-1], 1,
                                             stop=nchar(results[[5]][20])-1)))
  vr_ArSR <- rbind(vr_ArSR, as.double(substr(results[[7]][length(results[[7]])-1], 1, 
                                             stop=nchar(results[[7]][20])-1)))
  vr_ArCR <- rbind(vr_ArCR, as.double(substr(results[[9]][length(results[[9]])-1], 1,
                                             stop=nchar(results[[9]][20])-1)))
  vr_LLTSR <- rbind(vr_LLTSR, as.double(substr(results[[11]][length(results[[11]])-1], 1, 
                                             stop=nchar(results[[11]][20])-1)))
  vr_LLTCR <- rbind(vr_LLTCR, as.double(substr(results[[13]][length(results[[13]])-1], 1,
                                             stop=nchar(results[[13]][20])-1)))
  
  mae_pred_LLSR <- as.double(results[[3]][length(results[[3]])])
  mae_pred_LLCR <- as.double(results[[5]][length(results[[5]])])
  mae_pred_ArSR <- as.double(results[[7]][length(results[[7]])])
  mae_pred_ArCR <- as.double(results[[9]][length(results[[9]])])
  mae_pred_LLTSR <- as.double(results[[11]][length(results[[11]])])
  mae_pred_LLTCR <- as.double(results[[13]][length(results[[13]])])

  results_df <- data.frame(matrix(ncol = 5, nrow = 0))
  x <- c("element_key", "model", "win_mean", "mad", "mae_pred")
  colnames(results_df) <- x
  
  results_df[nrow(results_df) + 1,] = list(ek, "LLSR", 
                                           mean(Winsorize(vr_LLSR, probs=c(0, 0.95))),
                                           mad(vr_LLSR),
                                           mae_pred_LLSR)
  results_df[nrow(results_df) + 1,] = list(ek, "LLCR", 
                                           mean(Winsorize(vr_LLCR, probs=c(0, 0.95))),
                                           mad(vr_LLCR),
                                           mae_pred_LLCR)
  results_df[nrow(results_df) + 1,] = list(ek, "ArSR", 
                                           mean(Winsorize(vr_ArSR, probs=c(0, 0.95))),
                                           mad(vr_ArSR),
                                           mae_pred_ArSR)
  results_df[nrow(results_df) + 1,] = list(ek, "ArCR", 
                                           mean(Winsorize(vr_ArCR, probs=c(0, 0.95))),
                                           mad(vr_ArCR),
                                           mae_pred_ArCR)
  results_df[nrow(results_df) + 1,] = list(ek, "LLTSR", 
                                           mean(Winsorize(vr_LLTSR, probs=c(0, 0.95))),
                                           mad(vr_LLTSR),
                                           mae_pred_LLTSR)
  results_df[nrow(results_df) + 1,] = list(ek, "LLTCR", 
                                           mean(Winsorize(vr_LLTCR, probs=c(0, 0.95))),
                                           mad(vr_LLTCR),
                                           mae_pred_LLTCR)
  
  file_string = paste("results_bsts_",toString(ek),".csv", sep="")
  fwrite(results_df, file=file_string)
}



